"""MCP client for Agent Gauntlet challenge tools.

This client connects to the Agent Gauntlet Platform MCP server (HTTP/SSE) to access
challenge tools like `arena.get_challenge`, `arena.clues.list`, and
`arena.time_remaining`, plus image challenge tools.

The MCP URL is derived from `ARENA_SERVER` by default, and the competitor key is
sent as the `X-Arena-API-Key` header.

Example:
    async with McpArenaClient() as client:  # or McpArenaClient("https://arena.example.com")
        challenge = await client.get_challenge("my-agent")
        clues = await client.list_clues("my-agent")
        clue = await client.get_clue("clue_0", "my-agent")
"""

from __future__ import annotations

import asyncio
import json
import random
import time
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, AsyncIterator
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

from mcp import ClientSession
from mcp.client.sse import sse_client
from mcp.shared.exceptions import McpError

from .config import get_api_base, get_arena_api_key, get_mcp_url


TRANSPORT_RETRY_ATTEMPTS = 3
TRANSPORT_RETRY_BASE_S = 0.1
SUBMIT_MIN_WINDOW_S = 20.0
MCP_RECONNECTS_PER_CALL = 1


@dataclass
class ChallengeInfo:
    """Challenge information from get_challenge."""

    challenge_type: str
    challenge_id: str
    puzzle_id: str
    description: str
    rules: str
    max_time_s: int
    clues: list[str]
    time_remaining_s: float
    raw_data: dict[str, Any]

    def __getattr__(self, name: str) -> Any:
        """Provide dynamic access to challenge fields returned by MCP.

        This keeps agents future-proof as new challenge keys are introduced
        (for example: video_url, output_format, required_tools).
        """
        if name in self.raw_data:
            return self.raw_data[name]
        raise AttributeError(name)

    @property
    def extra_text(self) -> str:
        """Flatten non-core challenge fields into searchable text."""
        core_keys = {
            "challenge_type",
            "challenge_id",
            "puzzle_id",
            "description",
            "rules",
            "max_time_s",
            "clues",
            "time_remaining_s",
        }
        parts: list[str] = []
        for key, value in self.raw_data.items():
            if key in core_keys:
                continue
            text = _stringify_challenge_value(value)
            if text:
                parts.append(f"{key}: {text}")
        return " ".join(parts).strip()


@dataclass
class ClueInfo:
    """Information about a specific clue."""

    clue_id: str
    text: str
    time_remaining_s: float


@dataclass
class ImageChallengeInfo:
    """Image challenge information from arena.image.get_challenge."""

    challenge_type: str
    challenge_id: str
    puzzle_id: str
    difficulty: str
    description: str
    prompt: str
    reference_notes: str
    max_time_s: int
    input_image_uri: str
    time_remaining_s: float


def tool_supports_input_property(
    tool_defs: list[Any],
    tool_name: str,
    property_name: str,
) -> bool:
    """Return True when a discovered MCP tool schema advertises an input property."""
    for tool_def in tool_defs:
        if str(getattr(tool_def, "name", "") or "").strip() != tool_name:
            continue
        input_schema = getattr(tool_def, "inputSchema", None)
        if not isinstance(input_schema, dict):
            return False
        properties = input_schema.get("properties")
        return isinstance(properties, dict) and property_name in properties
    return False


def resolve_tool_proxy_api_key(
    tool_defs: list[Any],
    tool_name: str,
    *,
    llm_api_key: str,
    arena_api_key: str,
) -> str | None:
    """Return a BYO proxy key only when both env and server schema allow it."""
    normalized_llm_key = str(llm_api_key or "").strip()
    normalized_arena_key = str(arena_api_key or "").strip()
    if not normalized_llm_key or normalized_llm_key == normalized_arena_key:
        return None
    if not tool_supports_input_property(tool_defs, tool_name, "proxy_api_key"):
        return None
    return normalized_llm_key


def build_image_tool_arguments(
    tool_defs: list[Any],
    tool_name: str,
    *,
    selected_model: str,
    llm_api_key: str,
    arena_api_key: str,
) -> dict[str, str]:
    """Build optional image-tool arguments advertised by the live MCP schema."""
    arguments: dict[str, str] = {}
    normalized_model = str(selected_model or "").strip()
    if normalized_model and tool_supports_input_property(
        tool_defs,
        tool_name,
        "model",
    ):
        arguments["model"] = normalized_model
    proxy_api_key = resolve_tool_proxy_api_key(
        tool_defs,
        tool_name,
        llm_api_key=llm_api_key,
        arena_api_key=arena_api_key,
    )
    if proxy_api_key:
        arguments["proxy_api_key"] = proxy_api_key
    return arguments


# The first request from a new process also sets up the TLS connection, which
# took 1.5s against Practice; a 1.5s limit then fell back to a wrong guess.
SESSION_LOOKUP_TIMEOUT_S = 10.0
SESSION_LOOKUP_ATTEMPTS = 2
COMPETITION_LOOKUP_TIMEOUT_S = 5.0


def _get_json(request: Request, *, timeout: float, attempts: int = 1) -> dict[str, Any] | None:
    """GET ``request`` as JSON; retry network errors, never an HTTP error reply."""
    for attempt in range(attempts):
        try:
            with urlopen(request, timeout=timeout) as response:
                payload = json.loads(response.read().decode("utf-8"))
            return payload if isinstance(payload, dict) else None
        except HTTPError:
            return None
        except (URLError, TimeoutError, OSError):
            if attempt + 1 >= attempts:
                return None
        except json.JSONDecodeError:
            return None
    return None


class McpArenaClient:
    """MCP client for Agent Gauntlet challenge tools.

    This client connects to the Agent Gauntlet Platform MCP server via SSE transport
    and provides methods to access challenge tools.

    Usage:
        async with McpArenaClient() as client:  # or McpArenaClient("https://arena.example.com")
            challenge = await client.get_challenge("my-agent")
    """

    def __init__(
        self,
        mcp_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
        transport_retry_enabled: bool = True,
    ) -> None:
        """Initialize the client.

        Args:
            mcp_url: Base URL for the Agent Gauntlet Platform MCP server; `/sse` is
                appended (default: ARENA_MCP_URL or derived from ARENA_SERVER)
            api_key: Competitor key sent as the `X-Arena-API-Key` header
                (default: ARENA_API_KEY env var)
            timeout: Connection timeout in seconds
        """
        base_url = get_mcp_url(mcp_url)
        # SSE endpoint is at /sse
        self.sse_url = f"{base_url.rstrip('/')}/sse"
        resolved_api_key = get_arena_api_key(api_key)
        self._headers = (
            {"X-Arena-API-Key": resolved_api_key}
            if resolved_api_key
            else {}
        )
        self.timeout = timeout
        self.transport_retry_enabled = bool(transport_retry_enabled)
        self._session: ClientSession | None = None
        self._context = None  # Kept for compatibility with older callers.
        self._transport_task: asyncio.Task | None = None
        self._transport_close_event: asyncio.Event | None = None
        self._operation_lock = asyncio.Lock()
        self.deadline_monotonic: float | None = None
        self.deadline_reserve_s = 0.0

    async def __aenter__(self) -> "McpArenaClient":
        """Enter async context and establish connection.

        The first SSE connect can hit a transient transport error before any
        challenge is fetched; retry it a few times instead of crashing the run.
        """
        attempts = 4 if self.transport_retry_enabled else 1
        for attempt in range(attempts):
            try:
                await self._open()
                return self
            except BaseException as exc:
                if attempt + 1 >= attempts or not self._is_transport_error(exc):
                    raise
                print(f"   MCP connect failed ({type(exc).__name__}); retrying.", flush=True)
                await asyncio.sleep(0.5 * (2**attempt))
        return self

    async def _open(self) -> None:
        loop = asyncio.get_running_loop()
        ready: asyncio.Future[ClientSession] = loop.create_future()
        close_event = asyncio.Event()
        self._transport_close_event = close_event
        self._transport_task = asyncio.create_task(
            self._own_session(ready, close_event),
            name="arena-mcp-session-owner",
        )
        try:
            self._session = await asyncio.wait_for(
                asyncio.shield(ready),
                timeout=max(1.0, self.timeout + 1.0),
            )
        except BaseException:
            close_event.set()
            task = self._transport_task
            if task is not None:
                # The owner can be stuck inside initialize() when the SSE
                # post_writer died (lost reply); waiting on it would hang the
                # heat forever. Cancel it and bound the wait.
                task.cancel()
                try:
                    await asyncio.wait({task}, timeout=5.0)
                except BaseException:
                    pass
            if not ready.done():
                ready.cancel()
            self._transport_task = None
            self._transport_close_event = None
            raise

    async def _own_session(
        self,
        ready: asyncio.Future[ClientSession],
        close_event: asyncio.Event,
    ) -> None:
        """Own AnyIO cancel scopes away from the agent's caller task."""
        try:
            async with sse_client(
                self.sse_url,
                headers=self._headers,
                timeout=self.timeout,
                sse_read_timeout=self.timeout,
            ) as (read, write):
                async with ClientSession(read, write) as session:
                    await session.initialize()
                    if not ready.done():
                        ready.set_result(session)
                    await close_event.wait()
        except asyncio.CancelledError as exc:
            if not ready.done():
                ready.set_exception(ConnectionError(f"MCP session setup cancelled: {exc}"))
        except BaseException as exc:
            if not ready.done():
                ready.set_exception(exc)

    async def _close(self, *, tolerate_errors: bool = False) -> None:
        task = self._transport_task
        close_event = self._transport_close_event
        self._session = None
        self._context = None
        self._transport_task = None
        self._transport_close_event = None
        if close_event is not None:
            close_event.set()
        if task is not None:
            # Bounded: a broken transport must not stall a reconnect for long.
            done, _ = await asyncio.wait({task}, timeout=5.0)
            if not done:
                task.cancel()
                await asyncio.wait({task}, timeout=2.0)
            elif not tolerate_errors and not task.cancelled() and task.exception() is not None:
                raise task.exception()

    async def _reconnect(self) -> None:
        await self._close(tolerate_errors=True)
        await self._open()

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context and close connection."""
        await self._close(tolerate_errors=exc_type is not None)

    def set_deadline(
        self,
        deadline_monotonic: float | None,
        *,
        reserve_s: float = 0.0,
    ) -> None:
        """Set a local deadline and stop non-submit MCP retries before reserve."""
        self.deadline_monotonic = deadline_monotonic
        self.deadline_reserve_s = max(0.0, float(reserve_s))

    @staticmethod
    def _is_transport_error(exc: BaseException) -> bool:
        if isinstance(exc, RuntimeError) and "not connected" in str(exc).lower():
            return True
        if isinstance(exc, BaseExceptionGroup):
            leaves = list(exc.exceptions)
            return bool(leaves) and all(McpArenaClient._is_transport_error(e) for e in leaves)
        if isinstance(exc, (OSError, ConnectionError, TimeoutError, asyncio.TimeoutError)):
            return True
        if isinstance(exc, McpError):
            message = str(getattr(getattr(exc, "error", None), "message", exc)).lower()
            return any(
                marker in message
                for marker in (
                    "connection closed",
                    "transport closed",
                    "session closed",
                    "sse stream closed",
                    "end of stream",
                )
            )
        # MCP's SSE stack exposes transport breaks from AnyIO/httpx under
        # their own exception classes. Protocol/tool errors are not retried.
        name = type(exc).__name__
        module = type(exc).__module__.lower()
        if name == "HTTPStatusError" and module.startswith("httpx"):
            response = getattr(exc, "response", None)
            request = getattr(exc, "request", None)
            status = getattr(response, "status_code", None)
            url = str(getattr(request, "url", ""))
            if status in {404, 410} and "/messages" in url:
                return True
        return name in {
            "BrokenResourceError",
            "ClosedResourceError",
            "EndOfStream",
            "ConnectError",
            "ReadError",
            "ReadTimeout",
            "RemoteProtocolError",
            "WriteError",
        } and any(part in module for part in ("anyio", "httpx", "httpcore", "trio"))

    @staticmethod
    def _retry_delay(attempt: int) -> float:
        ceiling = TRANSPORT_RETRY_BASE_S * (2**attempt)
        return random.uniform(ceiling * 0.5, ceiling * 1.5)

    async def _call_with_retry(self, operation):
        """Serialize access to an SSE session, including reconnect and replay."""
        async with self._operation_lock:
            return await self._call_with_retry_locked(operation)

    async def _call_with_retry_locked(self, operation):
        """Retry a lost transport response; reconnect SSE once per operation."""
        started = time.monotonic()
        deadline = self.deadline_monotonic or (
            started + self.timeout * TRANSPORT_RETRY_ATTEMPTS + 1.0
        )
        reconnects = 0
        last_error: BaseException | None = None
        max_attempts = TRANSPORT_RETRY_ATTEMPTS if self.transport_retry_enabled else 1
        for attempt in range(max_attempts):
            remaining_s = deadline - time.monotonic() - self.deadline_reserve_s
            if remaining_s <= 0:
                break
            try:
                response = await asyncio.wait_for(operation(), timeout=remaining_s)
            except asyncio.CancelledError as cancelled:
                task = asyncio.current_task()
                # The MCP SSE reader can cancel its request task when the
                # stream ends. Preserve caller cancellation, but treat a
                # session-originated cancellation as a lost transport reply.
                if task is not None and task.cancelling():
                    raise
                exc: BaseException = ConnectionError("MCP SSE operation was cancelled by a closed session")
            except Exception as caught:
                exc = caught
            else:
                return response

            if not self._is_transport_error(exc):
                raise exc
            last_error = exc
            if attempt + 1 >= max_attempts:
                break
            if reconnects >= MCP_RECONNECTS_PER_CALL:
                break
            try:
                await self._reconnect()
            except Exception as reconnect_error:
                last_error = reconnect_error
                break
            reconnects += 1
            delay_s = self._retry_delay(attempt)
            if delay_s >= deadline - time.monotonic() - self.deadline_reserve_s:
                break
            await asyncio.sleep(delay_s)
        if last_error is not None:
            raise last_error
        raise TimeoutError("MCP call deadline expired before a transport retry")

    def _parse_result(self, result) -> dict[str, Any]:
        """Parse all MCP result blocks without assuming every block is text.

        Structured data and decoded text fields remain available at the top
        level for existing kit callers. The original content blocks and error
        marker are retained for consumers that need multimodal evidence.
        """
        data: dict[str, Any] = {}
        structured = getattr(result, "structuredContent", None)
        if structured is None:
            structured = getattr(result, "structured_content", None)
        if isinstance(structured, dict):
            data.update(structured)
            data["structuredContent"] = dict(structured)
        elif structured is not None:
            data["structuredContent"] = structured

        blocks: list[dict[str, Any]] = []
        raw_text_parts: list[str] = []
        for block in getattr(result, "content", None) or []:
            block_data = self._content_block_dict(block)
            if not block_data:
                continue
            blocks.append(block_data)
            text = self._content_block_text(block_data)
            if not text:
                continue
            raw_text_parts.append(text)
            try:
                decoded = json.loads(text)
            except (TypeError, json.JSONDecodeError):
                continue
            if isinstance(decoded, dict):
                data.update(decoded)
            elif isinstance(decoded, list):
                data.setdefault("raw_values", []).extend(decoded)

        if raw_text_parts and "raw" not in data:
            data["raw"] = "\n".join(raw_text_parts)
        if blocks:
            data["content"] = blocks
        data["isError"] = bool(
            getattr(result, "isError", getattr(result, "is_error", False))
        )
        return data

    @staticmethod
    def _content_block_dict(block: Any) -> dict[str, Any]:
        """Convert a typed MCP block to a JSON-friendly mapping safely."""
        if isinstance(block, dict):
            return dict(block)
        for method_name in ("model_dump", "dict"):
            method = getattr(block, method_name, None)
            if not callable(method):
                continue
            try:
                value = method(mode="json") if method_name == "model_dump" else method()
            except TypeError:
                try:
                    value = method()
                except Exception:
                    continue
            except Exception:
                continue
            if isinstance(value, dict):
                return value
        names = (
            "type", "text", "data", "mimeType", "mime_type", "uri", "resource",
            "annotations", "meta", "name", "description",
        )
        value: dict[str, Any] = {}
        for name in names:
            try:
                item = getattr(block, name)
            except Exception:
                continue
            if item is not None:
                value[name] = item
        if "type" not in value:
            class_name = type(block).__name__.lower()
            if "image" in class_name:
                value["type"] = "image"
            elif "text" in class_name:
                value["type"] = "text"
            elif "resource" in class_name and "link" in class_name:
                value["type"] = "resource_link"
            elif "resource" in class_name:
                value["type"] = "resource"
        return value

    @staticmethod
    def _content_block_text(block: dict[str, Any]) -> str:
        text = block.get("text")
        if isinstance(text, str) and text.strip():
            return text.strip()
        resource = block.get("resource")
        if isinstance(resource, dict):
            nested = resource.get("text")
            if isinstance(nested, str) and nested.strip():
                return nested.strip()
        return ""

    @staticmethod
    def _normalize_clues(value: Any) -> list[str]:
        if not value:
            return []
        if isinstance(value, str):
            text = value.strip()
            return [text] if text else []
        if not isinstance(value, list):
            text = str(value).strip()
            return [text] if text else []

        normalized: list[str] = []
        for item in value:
            if isinstance(item, str):
                text = item.strip()
                if text:
                    normalized.append(text)
                continue
            if isinstance(item, dict):
                clue_text = item.get("text")
                if isinstance(clue_text, str) and clue_text.strip():
                    normalized.append(clue_text.strip())
                    continue
            text = str(item).strip()
            if text:
                normalized.append(text)
        return normalized

    async def list_tools(self) -> list[str]:
        """List available tools.

        Returns:
            List of tool names
        """
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")
        tools: list[Any] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()
        while True:
            result = await self._call_with_retry(
                lambda page_cursor=cursor: self._session.list_tools(cursor=page_cursor)
            )
            tools.extend(result.tools)
            next_cursor = getattr(result, "nextCursor", None) or getattr(result, "next_cursor", None)
            if not next_cursor or str(next_cursor) in seen_cursors:
                break
            cursor = str(next_cursor)
            seen_cursors.add(cursor)
        names: list[str] = []
        for tool in tools:
            name = str(getattr(tool, "name", "") or "")
            if name and name not in names:
                names.append(name)
        return names

    async def list_tool_defs(self) -> list[Any]:
        """List full available tool definitions (with schemas)."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")
        tools: list[Any] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()
        while True:
            result = await self._call_with_retry(
                lambda page_cursor=cursor: self._session.list_tools(cursor=page_cursor)
            )
            tools.extend(result.tools)
            next_cursor = getattr(result, "nextCursor", None) or getattr(result, "next_cursor", None)
            if not next_cursor or str(next_cursor) in seen_cursors:
                break
            cursor = str(next_cursor)
            seen_cursors.add(cursor)
        unique: list[Any] = []
        seen_names: set[str] = set()
        for tool in tools:
            name = str(getattr(tool, "name", "") or "")
            if name and name not in seen_names:
                unique.append(tool)
                seen_names.add(name)
        return unique

    async def list_resources(self) -> list[Any]:
        """List every MCP resource, following pagination cursors."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")
        resources: list[Any] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()
        while True:
            result = await self._call_with_retry(
                lambda page_cursor=cursor: self._session.list_resources(cursor=page_cursor)
            )
            resources.extend(getattr(result, "resources", []) or [])
            next_cursor = getattr(result, "nextCursor", None) or getattr(result, "next_cursor", None)
            if not next_cursor or str(next_cursor) in seen_cursors:
                break
            cursor = str(next_cursor)
            seen_cursors.add(cursor)
        return resources

    async def read_resource(self, uri: str) -> Any:
        """Read an MCP resource through the same transport retry boundary."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")
        return await self._call_with_retry(lambda: self._session.read_resource(uri))

    async def list_prompts(self) -> list[Any]:
        """List every MCP prompt, following pagination cursors."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")
        prompts: list[Any] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()
        while True:
            result = await self._call_with_retry(
                lambda page_cursor=cursor: self._session.list_prompts(cursor=page_cursor)
            )
            prompts.extend(getattr(result, "prompts", []) or [])
            next_cursor = getattr(result, "nextCursor", None) or getattr(result, "next_cursor", None)
            if not next_cursor or str(next_cursor) in seen_cursors:
                break
            cursor = str(next_cursor)
            seen_cursors.add(cursor)
        return prompts

    async def get_prompt(self, name: str, arguments: dict[str, str] | None = None) -> Any:
        """Fetch a named MCP prompt and its messages."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")
        return await self._call_with_retry(
            lambda: self._session.get_prompt(name, arguments or {})
        )

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Call any MCP tool by name and return parsed JSON."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")

        payload = arguments or {}
        result = await self._call_with_retry(lambda: self._session.call_tool(name, payload))
        return self._parse_result(result)

    @staticmethod
    def detect_modality(tools: list[str], agent_id: str | None = None) -> str:
        """Detect active challenge modality.

        Detection order:
        1) This agent's session challenge_type (when agent_id is given and the
           agent has registered)
        2) Competition API challenge_type (if reachable)
        3) Tool-set fallback heuristics

        The session comes first because Practice in mixed mode alternates text
        and image per registration, and after each registration
        /api/competition already describes the next agent's challenge.
        """
        api_base = get_api_base()
        if api_base and agent_id:
            request = Request(
                f"{api_base.rstrip('/')}/api/session/{quote(agent_id, safe='')}",
                headers={
                    "Accept": "application/json",
                    "X-Arena-API-Key": get_arena_api_key(),
                },
                method="GET",
            )
            payload = _get_json(
                request,
                timeout=SESSION_LOOKUP_TIMEOUT_S,
                attempts=SESSION_LOOKUP_ATTEMPTS,
            )
            session_type = str((payload or {}).get("challenge_type") or "").lower()
            if session_type in {"text", "image"}:
                return session_type

        if api_base:
            request = Request(
                f"{api_base.rstrip('/')}/api/competition",
                headers={"Accept": "application/json"},
                method="GET",
            )
            payload = _get_json(request, timeout=COMPETITION_LOOKUP_TIMEOUT_S)
            challenge_type = str((payload or {}).get("challenge_type") or "").lower()
            if "image" in challenge_type:
                return "image"
            if challenge_type:
                return "text"

        tool_set = set(tools)
        has_text = "arena.get_challenge" in tool_set
        has_image = "arena.image.get_challenge" in tool_set
        if has_image and not has_text:
            return "image"
        if has_text:
            return "text"
        return "text"

    async def get_challenge(self, agent_id: str = "default") -> ChallengeInfo:
        """Get the current challenge and start the timer.

        Args:
            agent_id: Unique identifier for the agent

        Returns:
            ChallengeInfo with puzzle details
        """
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")

        data = await self.call_tool("arena.get_challenge", {"agent_id": agent_id})

        if "error" in data:
            raise McpArenaError(data["error"])

        return ChallengeInfo(
            challenge_type=data.get("challenge_type", ""),
            challenge_id=data.get("challenge_id", ""),
            puzzle_id=data.get("puzzle_id", ""),
            description=data.get("description", ""),
            rules=data.get("rules", ""),
            max_time_s=data.get("max_time_s", 0),
            clues=self._normalize_clues(data.get("clues")),
            time_remaining_s=data.get("time_remaining_s", 0),
            raw_data=dict(data),
        )

    async def get_image_challenge(self, agent_id: str = "default") -> ImageChallengeInfo:
        """Get the current image challenge and start its timer."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")

        data = await self.call_tool("arena.image.get_challenge", {"agent_id": agent_id})
        if "error" in data:
            raise McpArenaError(data["error"], code=data.get("code"))

        prompt = data.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            prompt = data.get("edit_prompt", "")
        if not isinstance(prompt, str):
            prompt = ""

        return ImageChallengeInfo(
            challenge_type=data.get("challenge_type", ""),
            challenge_id=data.get("challenge_id", ""),
            puzzle_id=data.get("puzzle_id", ""),
            difficulty=data.get("difficulty", ""),
            description=data.get("description", ""),
            prompt=prompt,
            reference_notes=data.get("reference_notes", ""),
            max_time_s=data.get("max_time_s", 0),
            input_image_uri=data.get("input_image_uri", ""),
            time_remaining_s=data.get("time_remaining_s", 0),
        )

    async def list_clues(self, agent_id: str = "default") -> list[str]:
        """List available clue IDs.

        Args:
            agent_id: Unique identifier for the agent

        Returns:
            List of clue IDs
        """
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")

        data = await self.call_tool("arena.clues.list", {"agent_id": agent_id})

        if "error" in data:
            raise McpArenaError(data["error"])

        return data.get("clue_ids", [])

    async def get_clue(self, clue_id: str, agent_id: str = "default") -> ClueInfo:
        """Get a specific clue by ID.

        Args:
            clue_id: The clue ID (e.g., "clue_0")
            agent_id: Unique identifier for the agent

        Returns:
            ClueInfo with clue text
        """
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")

        data = await self.call_tool(
            "arena.clues.get",
            {"clue_id": clue_id, "agent_id": agent_id},
        )

        if "error" in data:
            raise McpArenaError(data["error"])

        clue_text = data.get("text", "")
        if not isinstance(clue_text, str) or not clue_text.strip():
            block_texts = [
                self._content_block_text(block)
                for block in data.get("content", [])
                if isinstance(block, dict)
            ]
            clue_text = "\n".join(text for text in block_texts if text)

        return ClueInfo(
            clue_id=data.get("clue_id", clue_id),
            text=clue_text,
            time_remaining_s=data.get("time_remaining_s", 0),
        )

    async def get_all_clue_texts(self, agent_id: str = "default") -> list[str]:
        """Fetch every listed clue in server order."""
        clue_ids = await self.list_clues(agent_id)
        clues = [await self.get_clue(clue_id, agent_id) for clue_id in clue_ids]
        return [clue.text for clue in clues if clue.text.strip()]

    async def time_remaining(self, agent_id: str = "default") -> dict[str, Any]:
        """Get remaining time for the current match.

        Args:
            agent_id: Unique identifier for the agent

        Returns:
            Dictionary with time_remaining_s, elapsed_s, max_time_s, expired
        """
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")

        data = await self.call_tool("arena.time_remaining", {"agent_id": agent_id})

        if "error" in data:
            raise McpArenaError(data["error"])

        return data

    async def broadcast_image_thought(
        self,
        thought: str,
        agent_id: str = "default",
    ) -> dict[str, Any]:
        """Broadcast thought text through the image challenge channel."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")

        data = await self.call_tool(
            "arena.image.broadcast_thought",
            {"thought": thought, "agent_id": agent_id},
        )
        raw_message = data.get("raw")
        if isinstance(raw_message, str):
            lowered = raw_message.strip().lower()
            if lowered.startswith("error executing tool"):
                raise McpArenaError(raw_message)
        if "error" in data:
            raise McpArenaError(data["error"])
        return data

    async def submit_image(
        self,
        agent_id: str,
        image_uri: str,
        client_metrics: dict[str, Any] | None = None,
        rationale: str = "",
    ) -> dict[str, Any]:
        """Submit an image output via arena.image.submit_edit."""
        if not self._session:
            raise RuntimeError("Client not connected. Use 'async with' context.")

        # Always send the submit and give the judge time to reply, even near
        # or after the challenge deadline (late answers are still judged).
        previous = (self.deadline_monotonic, self.deadline_reserve_s)
        floor = time.monotonic() + SUBMIT_MIN_WINDOW_S
        if self.deadline_monotonic is None or self.deadline_monotonic < floor:
            self.deadline_monotonic = floor
        self.deadline_reserve_s = 0.0
        try:
            data = await self.call_tool(
                "arena.image.submit_edit",
                {
                    "edited_image": image_uri,
                    "client_metrics": client_metrics or {},
                    "rationale": rationale,
                    "agent_id": agent_id,
                },
            )
        finally:
            self.deadline_monotonic, self.deadline_reserve_s = previous
        if "error" in data:
            raise McpArenaError(data["error"])
        return data


class McpArenaError(Exception):
    """Error from the Agent Gauntlet Platform MCP server."""

    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        raw_code = str(code or "").strip()
        self.code = raw_code or None
        self.terminal = self.code == "not_image_challenge"

    @property
    def is_terminal(self) -> bool:
        """True when the agent should stop retrying this challenge tool."""
        return self.code == "not_image_challenge"


def _stringify_challenge_value(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, list):
        parts = [_stringify_challenge_value(item) for item in value]
        return " ".join(part for part in parts if part).strip()
    if isinstance(value, dict):
        if isinstance(value.get("text"), str):
            text = value.get("text", "").strip()
            if text:
                return text
        try:
            return json.dumps(value, ensure_ascii=True, sort_keys=True)
        except Exception:
            return str(value)
    return str(value)


@asynccontextmanager
async def connect_arena_mcp(
    mcp_url: str | None = None,
) -> AsyncIterator[McpArenaClient]:
    """Convenience context manager for connecting to Agent Gauntlet Platform MCP.

    Example:
        async with connect_arena_mcp() as client:  # or connect_arena_mcp("https://arena.example.com")
            challenge = await client.get_challenge("my-agent")
    """
    client = McpArenaClient(mcp_url)
    async with client:
        yield client
